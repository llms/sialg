$( document ).ready(function() {
   console.log(Dashboards.getQueryParameter("dataInicio"));
   // init();
});